import { test, expect } from '@playwright/test';

test.setTimeout(120000);

// Helper function to get output translation
async function getOutputTranslation(page) {
  const output = await page.evaluate(() => {
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    const sinhalaRegex = /[\u0D80-\u0DFF]{3,}/;
    const textNodes = [];
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent?.trim() || '';
      if (sinhalaRegex.test(text) && text.length < 300 && !text.includes('Undo') &&
          !text.includes('Redo') && !text.includes('Touchpad') && !text.includes('Swap')) {
        textNodes.push({text, element: node.parentElement});
      }
    }
    
    if (textNodes.length > 0) {
      return textNodes[textNodes.length - 1].text;
    }
    return '';
  });
  
  return output.trim();
}

test.describe('Positive Functional Tests - Singlish to Sinhala Translation', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto('https://www.swifttranslator.com/', { 
      waitUntil: 'domcontentloaded',
      timeout: 60000 
    });
    
    await page.waitForLoadState('networkidle', { timeout: 60000 });
    await page.waitForSelector('textarea', { state: 'visible', timeout: 30000 });
  });

  test('Pos_Fun_0001: Convert simple present tense sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mama paasalee innee');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0002:Convert compound sentence with connectort', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mama pansal yanavaa saha passe api kathaa karamu');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0003:Convert complex conditional sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('oyaa enavaanam mama balan innavaa');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0004: Convert interrogative question', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('hariyata kiyanna');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0005: Convert imperative command', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('issarahata yanna');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0006: Convert negative sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mama ehema karanne naehae');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0007: Convert polite request', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('karuNaakaralaa mata podi udhavvak karanna puLuvandha');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0008: Convert informal phrase', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('ehema karapan');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0009: Convert repeated words for emphasis', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('hari hari');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0010: Convert joined words input', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('Convert joined words input');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0011: Convert mixed Singlish and English terms', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('api Zoom meeting ekak thiyennee heta');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0012: Convert sentence with place name', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('api Kandy valata trip ekak yamu');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0013: Convert past tense sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mama iiyee gedhara giyaa');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0014: Convert future tense sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mama heta enavaa');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0015: Convert plural pronoun sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('api yamu');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0016: Convert currency format', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('Rs. 5343 ganna puluvan');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0017: Convert time format', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('7.30 AM enna');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0018: Convert sentence with abbreviation', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('magee NIC eka dhenna');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0019: Negation patterns', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('api eekata kaemathi naee');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0020: Convert multi-line input', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mama gedhara yanavaa api passe kathaa karamu');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0021: Greetings', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('oyaava dhaekiima sathutak!');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0022:  Request forms with varying degrees of politeness', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('mata ara tika ganna puLuvandha?');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0023: Convert sentence with units', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('kilo 5kg ganna');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

  test('Pos_Fun_0024: Convert pronoun variation sentence', async ({ page }) => {
    const inputField = page.locator('textarea').first();
    await inputField.waitFor({ state: 'visible', timeout: 10000 });
    await inputField.clear();
    await inputField.fill('eyaalaa enavaa');
    await page.waitForTimeout(3000);
    
    const actualOutput = await getOutputTranslation(page);
    expect(actualOutput.length).toBeGreaterThan(0);
  });

});